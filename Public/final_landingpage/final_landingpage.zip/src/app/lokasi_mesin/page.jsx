import React from 'react';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';

export default function page() {
	return (
		<>
			<Nav />
			<Footer />
		</>
	);
}
