import React from 'react';

export default function ScanBT() {
	return <div>ScanBT</div>;
}
