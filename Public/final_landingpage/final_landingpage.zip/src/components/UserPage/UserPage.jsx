import React from 'react';
import UserData from './UserData';
import ScanBT from './ScanBT';
import UploadButton from './UpBT';
import FileView from './FileView';

export default function UserPage() {
	return (
		<>
			<UserData />
			<ScanBT />
			<UploadButton />
			<FileView />
		</>
	);
}
