import React from 'react';

export default function Scanner() {
	return <div>Scanner</div>;
}
