import React from 'react';

export default function UserData() {
	return (
		<section className='text-gray-600 body-font overflow-hidden'>
			<div className='container px-5 py-24 mx-auto'>
				<div className='lg:w-4/5 mx-auto flex'>
					<img
						alt='profile'
						className='lg:w-1/4 w-1/4 h-auto mr-5 object-cover object-center rounded'
						src='https://dummyimage.com/400x400'
					/>
					<div className='lg:w-2/3 lg:pl-10 lg:py-6 mt-6 lg:mt-0'>
						<h2 className='text-sm title-font text-gray-500 tracking-widest'>
							Selamat datang
						</h2>
						<h1 className='text-gray-900 text-3xl title-font font-medium mb-1'>
							Username
						</h1>
						<div className='flex items-center'>
							<span className='title-font font-medium mr-2 text-2xl text-gray-900'>
								Saldo: Rp. 100.000
							</span>
							<button className='flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded'>
								Top Up Saldo
							</button>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
}
