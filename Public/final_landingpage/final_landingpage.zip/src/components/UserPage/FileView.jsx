import React from 'react';

export default function FileView() {
	return <div>FileView</div>;
}
