'use client';

import React, { useState, useEffect } from 'react';

const COUNTDOWN_TARGET = new Date('2023-11-22T09:00:00');

const getTimeLeft = () => {
	const totalTimeLeft = COUNTDOWN_TARGET - new Date();
	const hari = Math.floor(totalTimeLeft / (1000 * 60 * 60 * 24));
	const jam = Math.floor((totalTimeLeft / (1000 * 60 * 60)) % 24);
	const menit = Math.floor((totalTimeLeft / (1000 * 60)) % 60);
	const detik = Math.floor((totalTimeLeft / 1000) % 60);
	return { hari, jam, menit, detik };
};

const Countdown = () => {
	const [timeLeft, setTimeLeft] = useState(() => getTimeLeft());

	useEffect(() => {
		const timer = setInterval(() => {
			setTimeLeft(getTimeLeft());
		}, 1000);

		return () => {
			clearInterval(timer);
		};
	}, []);

	return (
		<header className='bg-white h-auto mb-10'>
			<div className='max-w-4xl mx-auto py-16 px-14 sm:px-6 lg:px-8'>
				<h1 className='font-sans font-bold text-4xl md:text-5xl lg:text-8xl text-center leading-snug text-gray-800'>
					Nantikan Keseruannya
				</h1>
				<div className='max-w-xl mx-auto'>
					<p className='mt-10 text-gray-500 text-center text-xl lg:text-3xl'>
						Selamat datang di masa depan Sains, Teknologi, dan Percetakan! Kami
						sedang mempersiapkan produk dan layanan revolusioner yang akan
						mengubah cara Anda berinteraksi dengan dunia sekitar. Tunggu apa
						yang akan terjadi dalam hitungan mundur ini, karena sesuatu yang
						besar akan segera tiba!
					</p>
				</div>
				<div className='mt-5 flex justify-center items-center w-full mx-auto'></div>
			</div>

			<div className='countdown'>
				<div className='flex flex-row justify-center md:justify-between gap-5'>
					{Object.entries(timeLeft).map(([label, value]) => (
						<div
							key={label}
							className='flex flex-col items-center justify-center w-full md:w-1/2 lg:w-1/4 max-w-150 h-150 mb-5 md:mb-0'>
							<div
								className={`w-28 h-28 md:w-40 md:h-40 lg:w-60 lg:h-60 bg-blue-700 text-gray-100 font-bold text-3xl md:text-5xl lg:text-8xl flex justify-center items-center rounded-lg`}>
								<span>{value}</span>
							</div>
							<span className='label mt-3 text-2xl md:text-base lg:text-lg font-light uppercase tracking-wide'>
								{label}
							</span>
						</div>
					))}
				</div>
			</div>
		</header>
	);
};

export default Countdown;
