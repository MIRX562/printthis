import Head from 'next/head';
import { Inter } from 'next/font/google';
import '../styles/globals.css';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';
import Countdown from '@/components/Countdown';
import Steps from '@/components/Steps';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
	title: 'PrintThis.id',
	description: 'Masih pemula puh sepuh',
};

export default function RootLayout({ children }) {
	return (
		<html lang='en'>
			<Head>
				<link rel='icon' href='/logo.ico' />
			</Head>

			<body className={inter.className}>
				<Nav />
				<Countdown />
				<Steps />
				{children}
				<Footer />
			</body>
		</html>
	);
}
